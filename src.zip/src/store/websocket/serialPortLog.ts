import { createPinia, defineStore } from 'pinia';
import { reactive } from 'vue';

const pinia = createPinia();

interface WebSocketState {
  ws: WebSocket | null;
  lockReconnect: boolean;
  timeoutNum: NodeJS.Timeout | null;
  msg: MessageEvent | null;
}

export const useWebSocketStore = defineStore('websocket', {
  state: (): WebSocketState => reactive({
    ws: null,
    lockReconnect: false,
    timeoutNum: null,
    msg: null
  }),
  actions: {
    webSocketInit(url: string) {
      const ws = this.$state.ws;
      if (ws) {
				console.log('Connection success？');
        ws.close();
      }

      const newWebSocket = new WebSocket(url);

      newWebSocket.onopen = () => {
        console.log('Connection success...');
      };

      newWebSocket.onmessage = (res) => {
        console.log('successfully received msg from php');
        console.log(res.data);
        this.$state.msg = res;
      };

      newWebSocket.onclose = () => {
        console.log('Connection closed...');
        this.reconnect(url);
      };

      newWebSocket.onerror = () => {
        console.log('Connection error...');
        this.reconnect(url);
      };

      this.$state.ws = newWebSocket;
    },
    reconnect(url: string) {
      const { lockReconnect, timeoutNum } = this.$state;
      if (lockReconnect) {
        return;
      }

      this.$state.lockReconnect = true;

      if (timeoutNum) {
        clearTimeout(timeoutNum);
        this.$state.timeoutNum = null;
      }

      this.$state.timeoutNum = setTimeout(() => {
        this.webSocketInit(url);
        this.$state.lockReconnect = false;
      }, 5000);
    },
    webSocketSend(p: string) {
      const ws = this.$state.ws;

      if (!ws || ws.readyState !== WebSocket.OPEN) {
        console.warn('WebSocket is not connected');
        return;
      }

      ws.send(p);
    }
  }
});

export const useWebSocket = pinia.useStore(useWebSocketStore);
