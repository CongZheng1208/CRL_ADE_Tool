import WorkbenchHeader from './workbench-header/index.vue';
import WorkbenchMain from './workbench-main/index.vue';

export { WorkbenchHeader, WorkbenchMain };
