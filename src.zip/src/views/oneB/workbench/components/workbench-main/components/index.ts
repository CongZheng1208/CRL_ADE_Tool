import TechnologyCard from './technology-card.vue';
import ShortcutsCard from './shortcuts-card.vue';

export { TechnologyCard, ShortcutsCard };
