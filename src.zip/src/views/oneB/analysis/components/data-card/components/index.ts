import GradientBg from './gradient-bg.vue';

export { GradientBg };
