import BottomPart from './bottom-part/index.vue';
import ControlPart from './control-part/index.vue';

export { BottomPart, ControlPart };
