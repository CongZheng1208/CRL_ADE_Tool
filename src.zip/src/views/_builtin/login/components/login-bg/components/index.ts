import CornerTop from './corner-top.vue';
import CornerBottom from './corner-bottom.vue';

export { CornerTop, CornerBottom };
