import OtherLogin from './other-login.vue';
import OtherAccount from './other-account.vue';

export { OtherLogin, OtherAccount };
