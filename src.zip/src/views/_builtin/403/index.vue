<template>
  <exception-base type="403" />
</template>

<script lang="ts" setup></script>

<style scoped></style>
