import setupAssets from './assets';

export { setupAssets };
