<template>
  <global-content :show-padding="false" />
</template>

<script setup lang="ts">
import { GlobalContent } from '../common';

defineOptions({ name: 'BlankLayout' });
</script>

<style scoped></style>
