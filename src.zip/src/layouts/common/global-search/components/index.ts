import SearchModal from './search-modal.vue';

export { SearchModal };
