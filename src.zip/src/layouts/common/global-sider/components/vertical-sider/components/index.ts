import VerticalMenu from './vertical-menu.vue';

export { VerticalMenu };
