import VerticalSider from './vertical-sider/index.vue';
import VerticalMixSider from './vertical-mix-sider/index.vue';

export { VerticalSider, VerticalMixSider };
