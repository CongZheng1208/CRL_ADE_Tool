import ContextMenu from './context-menu.vue';

export { ContextMenu };
