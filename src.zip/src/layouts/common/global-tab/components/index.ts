import TabDetail from './tab-detail/index.vue';
import ReloadButton from './reload-button/index.vue';

export { TabDetail, ReloadButton };
