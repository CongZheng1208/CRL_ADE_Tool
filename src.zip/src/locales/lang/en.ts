import type { LocaleMessages } from 'vue-i18n';

const locale: LocaleMessages<I18nType.Schema> = {
  message: {
    system: {
      title: 'SoybeanAdmin'
    },
    routes: {
			IronBird: {
        _value: 'IronBird Lab',
				overview: 'Overview',
				resourceList: 'Resource list',
				topologyGraph: 'Topology Graph Legend',
      },
			oneB: {
        _value: '1B Lab',
        analysis: 'Analysis',
        workbench: 'Workbench'
      },
			fiveG: {
        _value: '5G Remote Lab',
				overview: 'Overview',
				resourceList: 'Resource list',
				topologyGraph: 'Topology Graph Legend',
				tools: {
          _value: 'Tools',
          debug: 'Debug tools',
					load: {
						_value: 'Load tools',
						leftCabinet: 'left cabinet',
						rightCabinet: 'right cabinet'
					},
					print: 'Print tools',
        }
      },
			exception: {
        _value: 'Exception',
        403: '403',
        404: '404',
        500: '500'
      },
    }
  }
};

export default locale;
